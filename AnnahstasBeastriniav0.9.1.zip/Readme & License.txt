#In order to ensure the integrity of the pack, I need all downloads to come from a single source, Minecarftforum.net via curse/twitch (atm it is also hosted on planetminecraft, the download will be redirected in the future, so do not fret ;) )
#If you find this pack HOSTED on another site, please notify me via private message on minecraft forum or post directly on the resourcepack page on curse, Thank you!

Compatible with Minecraft 1.11.x and snapshots of 1.12.x

---------------------------------------------------------------------------------------------------

 -Annahstas
I'm here today to share my version of a Pokemon Resourcepack. I love Pokemon and it would only be natural that I love Pixelmon as well which combines my two favorite games.
Now, the pack might be inspired by Pokemon but I have tried my best to keep most blocks and items instantly recognizable to vanilla Minecraft players.

I started playing Pixelmon recently and I failed to find an appealing Resourcepack yet again, so I decided It would be the last time I went looking for a Pokemon Resourcepack.

I have seen countless of Pokemon Resourcepacks, most of which are 16x, and I have never stayed with a specific one for a significant amount of time. Either they have too many random Pokemon items or they have no Pixelmon support.

The pack is updated several times a week and I have so far completed the first third of the block textures in only 4 days. So stay tuned for more!


Will have full item and block support for Pixelmon in the future.

-----------------------------------------------------------------------------------------------------

The name is derived from my never launched Pixelmon server. The main worlds name was/is Beastrinia (All the screenshots for this Resourcepack are taken in/from that world).
I have no plans to start the server back up at the moment, at least not until the Resourcepack is finished, but if someone wants to help out to host the server etc, then me and my husband would lend a hand with advertising etc. We  have a lot of experience with proxy servers and spigot. We never released a spongeforge server to the public, but we have had no problem managing plugins on it in the past.

Just send Filmjolk a pm on Curse if you are interested, or message me on Planetminecraft "Annahstas".


------------------------------------------------------------------------------------------------------

Legal stuff:


- Do not distribute Annahstas pack or textures and/or claim them as your own.

- Feel free to use in-game (loading the pack through the minecraft client), remix and/or edit the textures for your own personal use. However, you may not distribute the modified/remixed textures without my consent.

- Do not re-upload the pack elsewhere. I encourage people to link either this curse download "https://mods.curse.com/texture-packs/minecraft/264556-annahstas-beastrinia-pokemon-inspired-32x/download" or the pack thread on Planetminecraft. DO NOT link directly to cursecdn, this is to protect the packs integrity and to centralize comments/critique that may help me improve the pack. I do not see the reason as to why anyone would not link a self-updating link. I do not want people commenting on a week old or more upload, complaining or giving critique on things which might have already been fixed. If you really don't want to link the curse download provided above, please contact me either on minecraftforum.net via pm or by email to filmjolk_2@hotmail.com, specify as to why you can't/wont use the provided link and maybe I can set up another download link that better fits your needs.

- Feel free to take screenshots/video recordings in/from minecraft while using this pack and/or the contents/assets therein (loading the pack or parts of it through the minecraft client) and to distribute such content with or without commercial purposes.

- You are allowed to distribute the resourcepack within your Minecraft servers community* if you are the owner or acting on behalf of the owner of said server. This only applies to the server resourcepack prompt (serverside resourcepack) and does not include hosting this resourcepack on a server forum/website.

* Anyone who has ever connected to your server